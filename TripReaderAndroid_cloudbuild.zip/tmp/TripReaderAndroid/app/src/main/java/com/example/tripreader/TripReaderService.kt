package com.example.tripreader

import android.accessibilityservice.AccessibilityService
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.util.Log

class TripReaderService : AccessibilityService() {
    private var overlay: OverlayManager? = null
    private var previousSnapshot = ""
    override fun onServiceConnected() { super.onServiceConnected(); if (Settings.canDrawOverlays(this)) overlay = OverlayManager(this) }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        // Package IDs vary by release/region; verify on your own device.
        val isRideApp = pkg.startsWith("com.uber") || pkg == "com.ubercab.driver" || pkg.startsWith("com.bolt") || pkg == "ee.mtakso.driver"
        if (isRideApp) processEvent()
    }
    private fun processEvent() {
        val root = rootInActiveWindow ?: return
        val strings = mutableListOf<String>(); collect(root, strings)
        val snapshot = strings.joinToString("|"); if (snapshot == previousSnapshot) return; previousSnapshot = snapshot
        val fare = strings.firstOrNull { Regex("(?:€\\s*\\d+[.,]?\\d*|\\d+[.,]?\\d*\\s*€|EUR\\s*\\d+[.,]?\\d*)", RegexOption.IGNORE_CASE).containsMatchIn(it) }
        val distance = strings.firstOrNull { Regex("\\d+[.,]?\\d*\\s*(?:km|公里)", RegexOption.IGNORE_CASE).containsMatchIn(it) }
        val duration = strings.firstOrNull { Regex("\\d+\\s*(?:min|mins|minutes|minutos|hr|h)", RegexOption.IGNORE_CASE).containsMatchIn(it) }
        if (fare == null && distance == null && duration == null) return
        val info = TripInfo(fare, distance, duration)
        if (overlay == null && Settings.canDrawOverlays(this)) overlay = OverlayManager(this)
        overlay?.show(info); Log.d("TripReader", "Trip offer detected: $info")
    }
    private fun collect(node: AccessibilityNodeInfo, out: MutableList<String>) {
        if (node.className?.toString() == "android.widget.TextView") node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        for (i in 0 until node.childCount) node.getChild(i)?.let { collect(it, out) }
    }
    override fun onInterrupt() { overlay?.hide() }
    override fun onDestroy() { overlay?.hide(); overlay = null; super.onDestroy() }
}
