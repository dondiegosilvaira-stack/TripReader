package com.example.tripreader

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.text.NumberFormat
import java.util.Locale

class OverlayManager(context: Context) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val view = TextView(context).apply {
        setTextColor(Color.WHITE); textSize = 18f; setPadding(24,16,24,16)
        background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = 16f }
        text = "TripReader\nÀ espera de proposta…"
    }
    private var attached = false
    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 120 }

    fun show(info: TripInfo) {
        val fare = number(info.fare); val km = number(info.distanceKm); val mins = number(info.durationMin)
        val fmt = NumberFormat.getNumberInstance(Locale("pt", "PT"))
        val lines = mutableListOf<String>()
        if (fare != null && km != null && km > 0) lines += "${fmt.format(fare/km)} €/km" else lines += "€/km indisponível"
        if (fare != null && mins != null && mins > 0) lines += "${fmt.format(fare/(mins/60.0))} €/h"
        lines += listOfNotNull(info.fare, info.distanceKm, info.durationMin).joinToString(" · ")
        view.text = lines.joinToString("\n")
        if (!attached) { try { wm.addView(view, params); attached = true } catch (_: SecurityException) { } }
        else try { wm.updateViewLayout(view, params) } catch (_: IllegalStateException) { attached = false }
    }
    fun hide() { if (attached) { try { wm.removeView(view) } catch (_: IllegalArgumentException) { } finally { attached = false } } }
    private fun number(s: String?): Double? = s?.trim()?.replace(',', '.')?.replace(Regex("[^0-9.]"), "")?.toDoubleOrNull()
}
