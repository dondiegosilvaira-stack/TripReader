package com.example.tripreader

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(32,32,32,32) }
        val accessibilityButton = Button(this).apply { text = "Ativar acessibilidade"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        val overlayButton = Button(this).apply {
            text = "Permitir sobreposição"
            setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        }
        statusText = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER; setPadding(0,24,0,0) }
        layout.addView(accessibilityButton, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(overlayButton, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(statusText, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setContentView(layout)
    }
    override fun onResume() { super.onResume(); updateStatus() }
    private fun updateStatus() {
        val access = isTripReaderAccessibilityEnabled()
        val overlay = Settings.canDrawOverlays(this)
        statusText.text = if (access && overlay) "Tudo pronto, volta para a Uber ou Bolt" else
            "Permissões necessárias:\nAcessibilidade: ${if(access) "OK" else "Em falta"}\nSobreposição: ${if(overlay) "OK" else "Em falta"}"
    }
    private fun isTripReaderAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, TripReaderService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }
}
