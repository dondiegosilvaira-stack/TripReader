package com.example.tripreader
data class TripInfo(val fare: String?, val distanceKm: String?, val durationMin: String?)
