# TripReader Android project

Android Studio/Kotlin project (compileSdk 34, minSdk 24, targetSdk 34).

## Build
1. Open this folder in Android Studio and sync Gradle.
2. Build > Build APK(s), or run `gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).
3. APK output: `app/build/outputs/apk/debug/app-debug.apk`.
4. Install with `adb install -r app/build/outputs/apk/debug/app-debug.apk`.
5. In Android Settings, explicitly enable TripReader accessibility and overlay permission.

## Important
- Package identifiers and on-screen text differ across Uber/Bolt driver app versions, regions and languages. This is a heuristic prototype; it may not detect values reliably.
- Test first with mock data. The app only reads visible accessibility text; it does not accept trips or automate actions.
- Accessibility access and overlay permission are sensitive and require explicit user consent. Use only for the intended purpose and comply with app/platform policies.
